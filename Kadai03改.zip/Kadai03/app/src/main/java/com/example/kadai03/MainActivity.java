package com.example.kadai03;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    //Called when the user clicks the Send button
    @SuppressLint("SetTextI18n")
    public void sendMessage(View view){
        EditText editText1=(EditText)findViewById(R.id.edit_message);
        EditText editText2=(EditText)findViewById(R.id.edit_Text2);
        TextView textView_siki =(TextView)findViewById(R.id.view_siki);
        TextView textView =(TextView)findViewById(R.id.view_message);
        String message1 =editText1.getText().toString();
        String message2 =editText2.getText().toString();

        //stringをdoubleに変換
        double a=(double)Integer.parseInt(message1);
        double b=(double)Integer.parseInt(message2);

        //button + - ÷　×　によって計算を変更する。
        switch (view.getId()){
            case R.id.button_sum:
                //足し算
                double sum=(double)(a+b);
                //式を表示
                textView_siki.setText(del_siki(a)+"+"+del_siki(b)+"=");
                //足し算の結果を表示
                String for_sum=format(sum);
                String del_sum=del(for_sum);
                textView.setText(del_sum);
                break;
            case R.id.button_sub:
                //計算
                double sub=(double)(a-b);
                //式を表示
                textView_siki.setText(del_siki(a)+"-"+del_siki(b)+"=");
                //答えを表示
                String for_sub=format(sub);
                String del_sub=del(for_sub);
                textView.setText(del_sub);
                break;
            case R.id.button_mul:
                double mul=(double)(a*b);
                //式を表示,余分な0の削除はしとく
                textView_siki.setText(del_siki(a)+"×"+del_siki(b)+"=");
                //答えの表示
                String for_mul=format(mul);
                String del_mul=del(for_mul);
                textView.setText(del_mul);
                break;
            case R.id.button_div:
                double div=a/b;
                //余分な0の削除
                String res_a=del_siki(a);
                String res_b=del_siki(b);
                //式を表示
                textView_siki.setText(res_a+"÷"+res_b+"=");
                //答えを表示
                String for_div=format(div);
                String del_div=del(for_div);
                textView.setText(del_div);
                break;
            case R.id.button_clear:
                //式を削除
                textView_siki.setText("");
                //答えを削除
                textView.setText("");
                //二つの数字も削除
                editText1.setText("");
                editText2.setText("");
                break;

        }
    }
    //末尾の０の削除
    public static String format(double d)
    {
        String res_d;
        if(d == (long) d) {
            res_d = String.valueOf((int) d);
            return res_d;
        }else {
            res_d = String.valueOf(d);
            return res_d;
        }
    }
    //小数点以下を数える
    public int getPrecision(Double val){
        // JavaではFloat⇒int変換するやりかたは無駄な処理が多いので文字列化して数える
        String str = String.valueOf(val);

        // 文末が ".0"とか".00000"で終わってるやつは全部桁０とする
        if(str.matches("^.*\\.0+$")){
            return 0;
        }

        int index = str.indexOf(".");
        return str.substring(index + 1).length();
    }
    //小数点以下の削除
    public String del(String d){
        //doubleに変更
         double che_d=Double.valueOf(d);
         //小数点数える
         int count =getPrecision(che_d);
         //小数点を丸める
        BigDecimal bd = new BigDecimal(che_d);
        //小数点以下あれば(1以上)、少数第8位で切り捨て、なければそのまま表示
        if(count>=1){
            BigDecimal bd1= bd.setScale(8,RoundingMode.DOWN);
            //小数点以下の0削除
            BigDecimal bd_nozero=bd1.stripTrailingZeros();
            String res_d=String.valueOf(bd_nozero);
            return res_d;
        }else{
            String res_d=String.valueOf((long)che_d);
            return res_d;
        }
    }
    //式の余分な0の削除
    public String del_siki(double a){
        //stringに変換して余分な0の削除
        String str_a=String.valueOf(a);
        String res_a=del(str_a);
        //返り値
        return res_a;
    }
}
